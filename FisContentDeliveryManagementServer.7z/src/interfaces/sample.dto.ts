export class SampleDto {
  name: string;
}
 