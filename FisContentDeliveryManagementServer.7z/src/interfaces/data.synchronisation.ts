export interface SynchronisationData
{
    entityName:string,
    data:string[]
}